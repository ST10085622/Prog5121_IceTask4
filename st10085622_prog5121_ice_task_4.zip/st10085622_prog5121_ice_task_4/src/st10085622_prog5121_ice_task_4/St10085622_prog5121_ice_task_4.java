package st10085622_prog5121_ice_task_4;

import java.util.Scanner;

public class St10085622_prog5121_ice_task_4 {

       public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        
       
        int userInput;
        System.out.print("Please enter student percentage : ");
        userInput = sc.nextInt();
        
        if(userInput >= 90 && userInput <= 100){
            
            System.out.println("The student's Letter Grade is A");
        
        }
        else if (userInput >= 80 && userInput <= 89) {
            
            System.out.println("The student's Letter Grade is B");
            
        }
        else if (userInput >= 70 && userInput <= 79){

            System.out.println("The student's Letter Grade is C");
            
        }
        else if (userInput >= 60 && userInput <= 69){

            System.out.println("The student's Letter Grade is D");
            
        }
        else if (userInput < 60){

            System.out.println("The student's Letter Grade is F");
            
        }
        
        
       }
    
}
